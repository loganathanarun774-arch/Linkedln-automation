import React from 'react';
import './App.css';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Feed from './components/Feed';
import Widgets from './components/Widgets';
import ChatBox from './components/ChatBox';
import MessagingPopup from './components/MessagingPopup';

function App() {
    const [isMessagingOpen, setIsMessagingOpen] = React.useState(false);
    const [activeChat, setActiveChat] = React.useState(null);

    return (
        <div className="app">
            <Header setIsMessagingOpen={setIsMessagingOpen} />

            <div className="app__body">
                <Sidebar />
                <Feed />
                <Widgets />
            </div>

            {activeChat && <ChatBox user={activeChat} onClose={() => setActiveChat(null)} />}
            <MessagingPopup
                isOpen={isMessagingOpen}
                setIsOpen={setIsMessagingOpen}
                openChat={setActiveChat}
            />
        </div>
    );
}

export default App;
