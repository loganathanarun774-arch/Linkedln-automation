import React, { useState, useEffect, useRef } from 'react';
import { Avatar, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import VideoCallIcon from '@mui/icons-material/VideoCall';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import ImageOutlinedIcon from '@mui/icons-material/ImageOutlined';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import GifBoxOutlinedIcon from '@mui/icons-material/GifBoxOutlined';
import SentimentSatisfiedAltOutlinedIcon from '@mui/icons-material/SentimentSatisfiedAltOutlined';
import SendIcon from '@mui/icons-material/Send';

function ChatBox({ user, onClose }) {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        // Initialize with some mock history if needed, or based on the user prop
        setMessages([
            { text: `Hi ${user.name}, thanks for connecting!`, sender: 'me', timestamp: '10:00 AM' },
            { text: "Great to connect with you!", sender: 'them', timestamp: '10:05 AM' }
        ]);
        scrollToBottom();
    }, [user]);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        setMessages([...messages, { text: input, sender: 'me', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
        setInput("");
    };

    return (
        <div className="fixed bottom-0 right-[340px] w-[300px] h-[400px] bg-white rounded-t-lg shadow-[0_0_10px_rgba(0,0,0,0.15)] flex flex-col z-50 border border-gray-300">
            {/* Header */}
            <div className="flex items-center justify-between px-3 py-2 border-b border-gray-200 bg-white rounded-t-lg hover:bg-gray-50 cursor-pointer">
                <div className="flex items-center space-x-2 overflow-hidden">
                    <div className="relative flex-shrink-0">
                        <Avatar src={user.src} sx={{ width: 32, height: 32 }}>{user.name[0]}</Avatar>
                        <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border-2 border-white"></div>
                    </div>
                    <div className="flex flex-col min-w-0">
                        <h4 className="font-semibold text-sm text-gray-900 truncate">{user.name}</h4>
                        <span className="text-xs text-gray-500 truncate">Available on mobile</span>
                    </div>
                </div>
                <div className="flex items-center space-x-1 flex-shrink-0">
                    <IconButton size="small"><MoreHorizIcon fontSize="small" /></IconButton>
                    <IconButton size="small"><VideoCallIcon fontSize="small" /></IconButton>
                    <IconButton size="small"><StarBorderIcon fontSize="small" /></IconButton>
                    <IconButton size="small" onClick={onClose}><CloseIcon fontSize="small" /></IconButton>
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
                <div className="flex flex-col space-y-4">
                    {/* Intro Card */}
                    <div className="flex flex-col items-center mb-4 text-center">
                        <Avatar src={user.src} sx={{ width: 64, height: 64 }} className="mb-2">{user.name[0]}</Avatar>
                        <h3 className="font-semibold text-gray-900">{user.name}</h3>
                        <p className="text-xs text-gray-500">You connected 2 days ago</p>
                    </div>

                    {messages.map((msg, index) => (
                        <div key={index} className={`flex flex-col ${msg.sender === 'me' ? 'items-end' : 'items-start'}`}>
                            <div className={`max-w-[85%] rounded-lg p-2 text-sm ${msg.sender === 'me'
                                    ? 'bg-blue-100 text-gray-800 rounded-tr-none'
                                    : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none'
                                }`}>
                                {msg.text}
                            </div>
                            <span className="text-[10px] text-gray-400 mt-1 px-1">{msg.timestamp}</span>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>
            </div>

            {/* Input Area */}
            <div className="px-3 py-2 border-t border-gray-200 bg-white">
                <form onSubmit={handleSend} className="flex flex-col">
                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                handleSend(e);
                            }
                        }}
                        placeholder="Write a message..."
                        className="w-full resize-none outline-none text-sm min-h-[60px] max-h-[100px] mb-2 placeholder-gray-500"
                    />
                    <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1">
                            <IconButton size="small" className="!p-1"><ImageOutlinedIcon fontSize="small" className="text-gray-600" /></IconButton>
                            <IconButton size="small" className="!p-1"><AttachFileIcon fontSize="small" className="text-gray-600" /></IconButton>
                            <IconButton size="small" className="!p-1"><GifBoxOutlinedIcon fontSize="small" className="text-gray-600" /></IconButton>
                            <IconButton size="small" className="!p-1"><SentimentSatisfiedAltOutlinedIcon fontSize="small" className="text-gray-600" /></IconButton>
                        </div>
                        <div className="flex items-center bg-blue-600 rounded-full px-2 py-1 cursor-pointer hover:bg-blue-700 transition" onClick={handleSend}>
                            <span className="text-white text-xs font-semibold mr-1">Send</span>
                            <SendIcon className="text-white !w-3 !h-3" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default ChatBox;
