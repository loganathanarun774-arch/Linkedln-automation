import React, { useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import PublicIcon from '@mui/icons-material/Public';
import SentimentSatisfiedAltIcon from '@mui/icons-material/SentimentSatisfiedAlt';
import ImageIcon from '@mui/icons-material/Image';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import BarChartIcon from '@mui/icons-material/BarChart';
import ArticleIcon from '@mui/icons-material/Article';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { Avatar, IconButton } from '@mui/material';

function CreatePostModal({ isOpen, onClose, title = "Create a post", onPost }) {
    const [input, setInput] = useState("");

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-[50px] bg-black/60 transition-opacity animate-fadeIn">
            <div className="bg-white rounded-xl w-full max-w-[552px] relative flex flex-col shadow-lg animate-slideIn">
                {/* Header */}
                <div className="flex justify-between items-center px-6 py-4 border-b border-gray-100">
                    <h2 className="text-xl font-normal text-gray-900">{title}</h2>
                    <IconButton onClick={onClose} className="hover:bg-gray-100 rounded-full">
                        <CloseIcon className="text-gray-600" />
                    </IconButton>
                </div>

                {/* User Info */}
                <div className="px-6 py-3 flex items-start space-x-3">
                    <Avatar src="" className="w-12 h-12">AL</Avatar>
                    <div className="flex flex-col">
                        <div className="flex items-center">
                            <h3 className="font-semibold text-gray-900 text-lg">Arun Loganathan</h3>
                            <ArrowDropDownIcon className="text-gray-600 cursor-pointer" />
                        </div>
                        <div className="flex items-center space-x-1 border border-gray-400 rounded-full px-3 py-1 cursor-pointer hover:bg-gray-100 transition-colors w-fit">
                            <span className="font-semibold text-sm text-gray-600">Post to Anyone</span>
                        </div>
                    </div>
                </div>

                {/* Text Area */}
                <div className="px-6 py-2 flex-grow min-h-[150px]">
                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                                if (input.trim()) {
                                    onPost(input);
                                    setInput("");
                                }
                            }
                        }}
                        className="w-full h-full resize-none outline-none text-lg text-gray-800 placeholder-gray-400"
                        placeholder="What do you want to talk about?"
                        autoFocus
                    />
                </div>

                {/* Add to your post */}
                <div className="flex items-center px-6 pb-2">
                    <IconButton className="!p-2"><SentimentSatisfiedAltIcon className="!text-gray-500" /></IconButton>
                </div>


                {/* Footer */}
                <div className="px-6 py-3 flex items-center justify-between border-t border-gray-50">
                    <div className="flex items-center space-x-2">
                        <IconButton title="Add media" className="!p-2" onClick={() => alert("Media upload feature coming soon!")}><ImageIcon className="!text-gray-600" /></IconButton>
                        <IconButton title="Create an event" className="!p-2" onClick={() => alert("Event creation feature coming soon!")}><CalendarMonthIcon className="!text-gray-600" /></IconButton>
                        <IconButton title="Celebrate an occasion" className="!p-2" onClick={() => alert("Celebration feature coming soon!")}><WorkspacePremiumIcon className="!text-gray-600" /></IconButton>
                        <IconButton title="Share that you're hiring" className="!p-2" onClick={() => alert("Hiring feature coming soon!")}><BusinessCenterIcon className="!text-gray-600" /></IconButton>
                        <IconButton title="Create a poll" className="!p-2" onClick={() => alert("Poll feature coming soon!")}><BarChartIcon className="!text-gray-600" /></IconButton>
                        <IconButton title="Add a document" className="!p-2" onClick={() => alert("Document upload feature coming soon!")}><ArticleIcon className="!text-gray-600" /></IconButton>
                        <IconButton className="!p-2" onClick={() => alert("More options coming soon!")}><MoreHorizIcon className="!text-gray-600" /></IconButton>
                    </div>

                    <div className="flex items-center space-x-4 border-l border-gray-300 pl-4">
                        <div className="flex items-center space-x-1 cursor-pointer hover:bg-gray-100 rounded px-2 py-1 text-gray-500">
                            <AccessTimeIcon fontSize="small" />
                        </div>
                        <button
                            onClick={() => {
                                if (!input.trim()) {
                                    alert("Please write something to post!");
                                    return;
                                }
                                onPost(input);
                                setInput("");
                            }}
                            className="bg-blue-600 text-white font-semibold rounded-full px-6 py-1.5 hover:bg-blue-700 hover:scale-105 hover:shadow-lg transition-all duration-200 ease-in-out"
                        >
                            Post
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CreatePostModal;
