'use client';

import React, { useState } from 'react';
import CreateIcon from '@mui/icons-material/Create';
import InputOption from './InputOption';
import ImageIcon from '@mui/icons-material/Image';
import SubscriptionsIcon from '@mui/icons-material/Subscriptions';
import EventNoteIcon from '@mui/icons-material/EventNote';
import CalendarViewDayIcon from '@mui/icons-material/CalendarViewDay';
import Post from './Post';
import CreatePostModal from './CreatePostModal';

function Feed() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalTitle, setModalTitle] = useState("Create a post");

    const openModal = (title) => {
        setModalTitle(title);
        setIsModalOpen(true);
    };

    const handlePost = (message) => {
        setPosts([{
            id: Date.now(),
            name: "Arun Loganathan",
            description: "Member of the Technical Staff",
            message: message,
            photoUrl: "",
        }, ...posts]);
        setIsModalOpen(false);
    };

    const [posts, setPosts] = useState([
        {
            id: 1,
            name: 'ARUN lOGANATHAN',
            description: 'this is a test',
            message: 'WOW this works',
        },
        {
            id: 2,
            name: 'Elon Musk',
            description: 'Tesla CEO',
            message: 'Doge is going to the moon!',
        },
    ]);

    const sendPost = (e) => {
        e.preventDefault();
        // Logic for sending post would go here
    };

    return (
        <div className="flex-[0.6] my-0 mx-5 sm:flex-1">
            <div className="bg-white p-2.5 pb-[20px] rounded-[10px] mb-5">
                <div className="flex border border-gray-300 rounded-[30px] p-2.5 pl-[15px] text-gray-500 cursor-pointer" onClick={() => setIsModalOpen(true)}>
                    <CreateIcon />
                    <form className="flex w-full ml-2.5">
                        <input
                            type="text"
                            readOnly
                            className="border-none w-full ml-2.5 outline-none font-semibold flex-1 cursor-pointer"
                            placeholder="Start a post"
                        />
                        <button onClick={sendPost} type="submit" className="hidden">Send</button>
                    </form>
                </div>
                <div className="flex justify-evenly">
                    <InputOption Icon={ImageIcon} title="Photo" color="#70B5F9" onClick={() => openModal("Add a Photo")} />
                    <InputOption Icon={SubscriptionsIcon} title="Video" color="#E7A33E" onClick={() => openModal("Add a Video")} />
                    <InputOption Icon={EventNoteIcon} title="Event" color="#C0CBCD" onClick={() => openModal("Create an Event")} />
                    <InputOption Icon={CalendarViewDayIcon} title="Write article" color="#7FC15E" onClick={() => openModal("Write an Article")} />
                </div>
            </div>

            {/* Posts */}
            {posts.map(({ id, name, description, message }) => (
                <Post
                    key={id}
                    name={name}
                    description={description}
                    message={message}
                />
            ))}
            <Post name="Sonny Sangha" description="This is a test" message="Wow this works" />

            <CreatePostModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title={modalTitle}
                onPost={handlePost}
            />
        </div>
    )
}

export default Feed;
