'use client';

import React from 'react';
import SearchIcon from '@mui/icons-material/Search';
import HomeIcon from '@mui/icons-material/Home';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import ChatIcon from '@mui/icons-material/Chat';
import NotificationsIcon from '@mui/icons-material/Notifications';
import HeaderOption from './HeaderOption';

function Header({ setIsMessagingOpen }) {
    return (
        <div className="sticky top-0 z-50 bg-white flex justify-evenly items-center border-b border-gray-200 py-[5px] w-full">
            {/* Left */}
            <div className="flex items-center">
                <img
                    src="https://upload.wikimedia.org/wikipedia/commons/8/81/LinkedIn_icon.svg"
                    alt="logo"
                    className="object-contain h-10 mr-2.5"
                />

                <div className="p-2.5 flex items-center rounded bg-[#eef3f8] text-gray-500 h-[34px]">
                    <SearchIcon />
                    <input
                        type="text"
                        placeholder="Search"
                        className="outline-none border-none bg-transparent min-w-[200px]"
                    />
                </div>
            </div>

            {/* Right */}
            <div className="flex items-center">
                <HeaderOption Icon={HomeIcon} title="Home" />
                <HeaderOption Icon={SupervisorAccountIcon} title="My Network" />
                <HeaderOption Icon={BusinessCenterIcon} title="Jobs" />
                <HeaderOption
                    Icon={ChatIcon}
                    title="Messaging"
                    onClick={() => setIsMessagingOpen(prev => !prev)}
                />
                <HeaderOption Icon={NotificationsIcon} title="Notifications" />
                <HeaderOption avatar="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmf9-QeppAe23HuYBPz_0562e0Y8iMAoDj0A&s" title="Me" />
            </div>
        </div>
    );
}

export default Header;
