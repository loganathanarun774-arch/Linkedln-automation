'use client';
import { Avatar } from '@mui/material';
import React from 'react';

function HeaderOption({ avatar, Icon, title, onClick }) {
    return (
        <div onClick={onClick} className="group flex flex-col items-center cursor-pointer mr-5 hover:text-black">
            {Icon && <Icon className="!h-6 !w-6 text-gray-500 group-hover:text-black transition-all duration-300 ease-out" />}
            {avatar && (
                <Avatar className="!h-6 !w-6 !text-[10px]" src={avatar}>
                    {avatar[0]}
                </Avatar>
            )}
            <h3 className="text-xs text-gray-500 font-normal group-hover:text-black pt-1 hidden sm:block">
                {title}
            </h3>
        </div>
    );
}

export default HeaderOption;
