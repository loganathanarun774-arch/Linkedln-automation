'use client';
import React from 'react'

function InputOption({ Icon, title, color, onClick }) {
    return (
        <div onClick={onClick} className="flex items-center mt-[15px] text-gray-500 p-2.5 cursor-pointer hover:bg-gray-200 hover:rounded-[10px]">
            <Icon style={{ color: color }} />
            <h4 className="ml-[5px]">{title}</h4>
        </div>
    )
}

export default InputOption;
