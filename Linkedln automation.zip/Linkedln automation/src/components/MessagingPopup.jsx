import React from 'react';
import { Avatar } from '@mui/material';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import EditIcon from '@mui/icons-material/Edit';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import SearchIcon from '@mui/icons-material/Search';
import TuneIcon from '@mui/icons-material/Tune';

function MessagingPopup({ isOpen, setIsOpen, openChat }) {
    return (
        <div
            className={`fixed bottom-0 right-4 bg-white rounded-t-lg shadow-[0_4px_12px_rgba(0,0,0,0.15)] w-[300px] border border-gray-300 z-50 flex flex-col transition-all duration-300 ease-in-out ${isOpen ? 'h-[500px]' : 'h-[48px]'
                }`}
        >
            {/* Header */}
            <div
                className="flex items-center justify-between px-2 py-2 border-b border-gray-200 cursor-pointer hover:bg-gray-50 rounded-t-lg"
                onClick={() => setIsOpen(!isOpen)}
            >
                <div className="flex items-center space-x-2">
                    <div className="relative">
                        <Avatar
                            src="https://compassionate-leakey-e9b16b.netlify.app/images/IG_Sonny.jpeg"
                            sx={{ width: 32, height: 32 }}
                        />
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                    </div>
                    <span className="font-semibold text-sm text-gray-700">Messaging</span>
                </div>
                <div className="flex items-center text-gray-600 space-x-2">
                    <MoreHorizIcon className="!h-5 !w-5 cursor-pointer hover:bg-gray-200 rounded-full p-0.5" />
                    <EditIcon className="!h-5 !w-5 cursor-pointer hover:bg-gray-200 rounded-full p-0.5" />
                    <KeyboardArrowUpIcon
                        className={`!h-5 !w-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''
                            }`}
                    />
                </div>
            </div>

            {/* Content - Only show when open */}
            {isOpen && (
                <div className="flex-1 flex flex-col overflow-hidden bg-white">
                    {/* Search Bar */}
                    <div className="p-2">
                        <div className="flex items-center bg-[#eef3f8] rounded-md px-2 py-1">
                            <SearchIcon className="text-gray-500 !h-5 !w-5" />
                            <input
                                type="text"
                                placeholder="Search messages"
                                className="bg-transparent border-none outline-none text-sm ml-2 w-full placeholder-gray-500"
                            />
                            <TuneIcon className="text-gray-500 !h-5 !w-5 cursor-pointer" />
                        </div>
                    </div>

                    {/* Tabs */}
                    <div className="flex text-sm border-b border-gray-200">
                        <button className="flex-1 py-2 font-semibold text-green-700 border-b-2 border-green-700 hover:bg-gray-50">
                            Focused
                        </button>
                        <button className="flex-1 py-2 text-gray-500 font-semibold hover:bg-gray-50">
                            Other
                        </button>
                    </div>

                    {/* Message List */}
                    <div className="flex-1 overflow-y-auto">
                        {/* Mock Message Items */}
                        {[
                            {
                                name: 'Mritunjoy Das',
                                msg: 'You: Hi Sir, Thank you for shortlisting my profile and...',
                                date: 'Dec 15',
                                src: '',
                            },
                            {
                                name: 'Shridhar Naik',
                                msg: 'Shridhar: Hey Arun Based on your profile, I think you could...',
                                date: 'Dec 9',
                                src: '',
                            },
                            {
                                name: 'Kumaran K',
                                msg: 'You: No sir I got select on scholarship for full stack...',
                                date: 'Aug 5',
                                src: '',
                            },
                            {
                                name: 'Karthika Tamilselvan',
                                msg: 'You: Hi, Karthika Thanks for the opportunity i hope this...',
                                date: 'Aug 1',
                                src: '',
                            },
                            {
                                name: 'Sathish Gowthaman',
                                msg: "You: I'm at my native sir kindly arrange the appointment...",
                                date: 'Jul 14',
                                src: '',
                            },
                            {
                                name: 'The LinkedIn Team',
                                msg: "via LinkedIn The LinkedIn Team...",
                                date: 'May 12',
                                src: '',
                            },
                        ].map((item, index) => (
                            <div
                                key={index}
                                onClick={() => {
                                    openChat(item);
                                    if (!isOpen) setIsOpen(true);
                                }}
                                className="flex items-start p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-50 last:border-none"
                            >
                                <Avatar sx={{ width: 40, height: 40 }} className="mr-2">
                                    {item.name[0]}
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                    <div className="flex justify-between items-baseline">
                                        <h4 className="font-semibold text-sm text-gray-800 truncate">
                                            {item.name}
                                        </h4>
                                        <span className="text-xs text-gray-500 whitespace-nowrap ml-1">{item.date}</span>
                                    </div>
                                    <p className="text-xs text-gray-500 truncate">{item.msg}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default MessagingPopup;
