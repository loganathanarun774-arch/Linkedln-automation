'use client';

import { Avatar } from '@mui/material';
import React, { forwardRef } from 'react';
import InputOption from './InputOption';
import ThumbUpAltOutlinedIcon from '@mui/icons-material/ThumbUpAltOutlined';
import ChatOutlinedIcon from '@mui/icons-material/ChatOutlined';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import SendOutlinedIcon from '@mui/icons-material/SendOutlined';

const Post = forwardRef(({ name, description, message, photoUrl }, ref) => {
    const [liked, setLiked] = React.useState(false);

    return (
        <div ref={ref} className="bg-white p-[15px] mb-2.5 rounded-[10px]">
            <div className="flex mb-2.5 items-center">
                <Avatar src={photoUrl}>{name[0]}</Avatar>
                <div className="ml-2.5">
                    <h2 className="text-[15px] font-bold">{name}</h2>
                    <p className="text-xs text-gray-500">{description}</p>
                </div>
            </div>

            <div className="break-words">
                <p>{message}</p>
            </div>

            <div className="flex justify-evenly pt-2.5 border-t border-gray-200">
                <InputOption
                    Icon={ThumbUpAltOutlinedIcon}
                    title={liked ? "Liked" : "Like"}
                    color={liked ? "#0a66c2" : "gray"}
                    onClick={() => setLiked(!liked)}
                />
                <InputOption Icon={ChatOutlinedIcon} title="Comment" color="gray" onClick={() => alert("Comment feature coming soon!")} />
                <InputOption Icon={ShareOutlinedIcon} title="Share" color="gray" onClick={() => alert("Share feature coming soon!")} />
                <InputOption Icon={SendOutlinedIcon} title="Send" color="gray" onClick={() => alert("Send feature coming soon!")} />
            </div>
        </div>
    )
})

Post.displayName = 'Post';

export default Post;
