'use client';

import { Avatar } from '@mui/material';
import React from 'react';

function Sidebar() {
    const recentItem = (topic) => (
        <div className="flex text-xs text-gray-500 font-bold cursor-pointer mb-1 p-1 hover:bg-gray-200 hover:rounded-t-sm hover:text-black">
            <span className="ml-[5px] mr-[10px]">#</span>
            <p>{topic}</p>
        </div>
    );

    return (
        <div className="sticky top-20 flex-[0.2] rounded-[10px] text-center h-fit min-w-40 sm:min-w-48 md:min-w-[220px]">
            <div className="flex flex-col items-center border border-gray-300 border-b-0 rounded-t-[10px] bg-white pb-2.5">
                <img
                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/LinkedIn_2021.svg/1200px-LinkedIn_2021.svg.png"
                    alt=""
                    className="w-full h-[60px] rounded-t-[10px] object-cover -mb-5"
                />
                <Avatar className="mb-2.5 !w-[60px] !h-[60px] cursor-pointer">S</Avatar>
                <h2 className="text-lg font-bold">Arun Loganathan</h2>
                <h4 className="text-xs text-gray-500">loganathanarun774@gmail.com</h4>
            </div>

            <div className="p-2.5 mb-2.5 border border-gray-300 bg-white rounded-b-[10px]">
                <div className="flex justify-between items-center text-xs text-gray-500 font-semibold mb-2.5 hover:bg-gray-200 hover:rounded-sm cursor-pointer p-1">
                    <p>Who viewed you</p>
                    <p className="text-[#0a66c2] font-bold">2,543</p>
                </div>
                <div className="flex justify-between items-center text-xs text-gray-500 font-semibold hover:bg-gray-200 hover:rounded-sm cursor-pointer p-1">
                    <p>Views on post</p>
                    <p className="text-[#0a66c2] font-bold">2,448</p>
                </div>
            </div>

            <div className="text-left p-2.5 border border-gray-300 bg-white rounded-[10px] mt-2.5">
                <p className="text-xs pb-2.5">Recent</p>
                {recentItem('reactjs')}
                {recentItem('programming')}
                {recentItem('softwareengineering')}
                {recentItem('design')}
                {recentItem('developer')}
            </div>
        </div>
    );
}

export default Sidebar;
