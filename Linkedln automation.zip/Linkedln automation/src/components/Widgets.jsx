'use client';

import React from 'react';
import InfoIcon from '@mui/icons-material/Info';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';

function Widgets() {
    const newsArticle = (heading, subtitle) => (
        <div className="flex p-2.5 cursor-pointer hover:bg-gray-200 hover:rounded-[10px]">
            <div className="text-[#0a66c2] mr-[5px]">
                <FiberManualRecordIcon className="!text-[15px]" />
            </div>
            <div className="flex-1">
                <h4 className="text-sm font-bold">{heading}</h4>
                <p className="text-xs text-gray-500">{subtitle}</p>
            </div>
        </div>
    );

    return (
        <div className="sticky top-20 flex-[0.2] bg-white rounded-[10px] border border-gray-300 h-fit pb-2.5 hidden lg:block min-w-[250px]">
            <div className="flex items-center justify-between p-2.5">
                <h2 className="text-base font-bold">LinkedIn News</h2>
                <InfoIcon />
            </div>

            {newsArticle("PAPA React is back", "Top news - 9099 readers")}
            {newsArticle("Coronavirus: UK updates", "Top news - 886 readers")}
            {newsArticle("Tesla hits new highs", "Cars & auto - 300 readers")}
            {newsArticle("Bitcoin Breaks $22k", "Crypto - 8000 readers")}
            {newsArticle("Is Redux too good?", "Code - 123 readers")}
            {newsArticle("PAPAFAM launches course", "Top news - 6503 readers")}
        </div>
    );
}

export default Widgets;
